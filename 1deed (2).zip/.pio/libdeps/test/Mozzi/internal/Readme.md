# About this directory

These files are part of the Mozzi project, but not meant for direct inclusion by the user. Functions and macros in here may be subject to change without notice.

