/*
 * LowPassfilter.h
 *
 * This file is part of Mozzi.
 *
 * Copyright 2012-2024 Tim Barrass and the Mozzi Team
 *
 * Mozzi is licensed under the GNU Lesser General Public Licence (LGPL) Version 2.1 or later.
 *
 */


#ifndef LOWPASS_H_
#define LOWPASS_H_

#include<ResonantFilter.h>
#warning This header is deprecated, please use ResonantFilter.h instead.

#endif /* LOWPASS_H_ */
